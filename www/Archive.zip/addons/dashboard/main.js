// (C) Copyright 2015 Martin Dougiamas
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

angular.module('mm.addons.dashboard', [])


.constant('mmaDashboardPriority', 2000)

.config(function($stateProvider, $mmSideMenuDelegateProvider, mmaDashboardPriority) {

    $stateProvider
        .state('site.dashboard', {
            url: '/dashboard',
            views: {
                'site': {
                    controller: 'mmaDashboardCtrl',
                    controllerAs: 'dashboard',
                    templateUrl: 'addons/dashboard/templates/list.html'
                }
            }
        })
        .state('site.dashCourse', {
            url: '/course/:id',
            views: {
                'site': {
                    controller: 'mmaDashboardCourseCtrl',
                    controllerAs: 'dashboardCourse',
                    templateUrl: 'addons/dashboard/templates/course.html'
                }
            }
        });

    // Register side menu addon.
    $mmSideMenuDelegateProvider.registerNavHandler('mmaDashboard', '$mmaDashboardHandlers.sideMenuNav', mmaDashboardPriority);

})

.run(['$mmaDashboardCommon', '$rootScope', '$mmSite', '$mmEvents', 'mmCoreEventLanguageChanged', '$mmLang', function($mmaDashboardCommon, $rootScope, $mmSite, $mmEvents, mmCoreEventLanguageChanged, $mmLang) {
    // $rootScope.$watch($mmSite.getToken(), function(newVal, oldVal) {
    //     console.warn(newVal, oldVal);
    // });

    setTimeout(function() {
        if ($mmSite.getToken()) {
            $mmaDashboardCommon.getType().then(function(res) {
                if (res.data.gender) {
                    $rootScope.gender = res.data.gender;
                } else {
                    $rootScope.gender = 'm';
                }
            });
        }

    }, 1500);

    $mmLang.getCurrentLanguage().then(function(currentLanguage) {
        $rootScope.currentLang = currentLanguage;
    });

    $mmEvents.on(mmCoreEventLanguageChanged, function(data) {
        $mmLang.getCurrentLanguage().then(function(currentLanguage) {
            $rootScope.currentLang = currentLanguage;
        });
    });



}]);